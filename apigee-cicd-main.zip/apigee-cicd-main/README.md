# apigee-cicd

This repository contains the example code and configuration files to deploy an Apigee proxy and updating the Apigee api hub using gitlab pipelines.